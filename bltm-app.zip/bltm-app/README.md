# Bán Lộ Trừ Ma · app tra cứu và phiếu nhân vật

Web app (cài được lên điện thoại, mất mạng vẫn dùng) và app Android cho module Bán Lộ Trừ Ma.

- **Tra cứu**: phép, nghi lễ, Căn, pháp bảo, sau này thêm NPC, vong, hình vẽ. Có mạng thì tìm trong database, mất mạng thì tìm trong gói dữ liệu trên máy. Gõ có dấu hay không dấu đều được.
- **Phiếu nhân vật**: người chơi đăng nhập để lưu phiếu lên mạng, GM thấy và sửa được mọi phiếu. Chưa đăng nhập vẫn tạo phiếu trên máy được. Sửa lúc mất mạng thì lưu nháp, có mạng tự đồng bộ. Hai nơi cùng sửa một phiếu thì app hỏi giữ bản nào.

Hướng dẫn cài đặt từng bước: xem tài liệu "Hướng dẫn cài Bán Lộ Trừ Ma".

## Cấu trúc

| Thư mục | Là gì |
|---|---|
| `src/` | Code React. `lib/` là phần dữ liệu (API, offline, công thức), `views/` là các màn hình |
| `src/lib/rules.js` | Công thức trên phiếu: mod, thông thạo, máu, linh, AC, DC... theo luật bản 21/11/2026 |
| `src/lib/sheet.js` | Cấu trúc dữ liệu một phiếu nhân vật |
| `public/data/core.json` | Gói dữ liệu đi kèm app (dùng khi chưa có mạng lần nào) |
| `public/sw.js` | Service worker: lưu app để mất mạng vẫn mở được |
| `supabase/` | SQL tạo database: `schema.sql` → `storage.sql` → `seed.sql` |
| `scripts/build.mjs` | Build bằng esbuild ra `dist/` |
| `test/` | Server Supabase giả và kịch bản test bằng trình duyệt |
| `.github/workflows/build.yml` | GitHub tự build web lên Pages, và APK khi bấm tay |

## Chạy trên máy tính (tuỳ chọn)

```bash
npm install
npm run serve        # mở http://localhost:8080
python3 test/e2e.py  # cần Python + Playwright; chạy sau npm run build
```

## Cập nhật nội dung

- GM đăng nhập, vào **Tra cứu**: nút **+ Thêm mục** để thêm, chọn một mục rồi bấm **Sửa** để sửa, ẩn (chọn Nháp) hoặc xoá. App của mọi người tự tải phần mới khi có mạng; mục Nháp chỉ GM thấy.
- Trong màn hình Sửa có phần **Hình vẽ**: hình được thu nhỏ trên máy (tối đa 1600px, kèm bản nhỏ 360px) rồi tải lên bucket `media`. Đường dẫn hình lưu ở `data.hinh` của mục. Người chơi xem hình nào thì máy tự giữ lại; Cài đặt có nút tải hết hình để xem offline.
- Vẫn sửa trực tiếp được trong Supabase (Table Editor → `entries`).
- Database tạo trước 27/11/2026 cần chạy thêm `supabase/update-01.sql` một lần.
- Blog truyện ma, hồ sơ PC công khai và ảnh chân dung cần `supabase/update-02.sql` (chạy một lần, kể cả database mới tạo: schema → storage → seed → update-02).

## Các mục trong app

- **Truyện ma** (`#truyen`): khách gửi bài không cần tài khoản qua hàm `submit_post` (có ô bẫy và giới hạn 3 bài/giờ mỗi IP). GM duyệt ở `#truyen/duyet`.
- **Sổ phép** (`#tra-cuu`): phép hiện như lá bùa dán trên trang sổ chép tay, nghi lễ như lá sớ (`src/views/Folio.jsx`).
- **Nhân vật** (`#nhan-vat`): PC người chơi tự bật công khai (ô `cong_khai` trong phiếu, đọc qua hàm `public_characters`) và NPC (mục loại `npc` trong kho).
- **Phiếu của tôi** (`#phieu`): phiếu trình bày như sơ yếu lý lịch, có ảnh 3×4.
- Theme: `bao-cao` (mặc định), `crt`, `giay`, `dem`. Thêm theme mới: thêm khối `[data-theme=...]` trong `styles.css` và một dòng trong `src/lib/theme.js`.

## App Android

Workflow build APK mỗi lần đưa code lên `main`, đăng vào Releases với tag `app-android`; link tải cố định:
`https://github.com/<chủ>/<repo>/releases/latest/download/ban-lo-tru-ma.apk`.
Khoá ký nằm ở `android-keystore/debug.keystore` để bản sau cài đè được bản trước. Biểu tượng và màn hình chờ lấy từ `assets/`.
- Muốn gói đi kèm app cũng mới theo: xuất bảng `entries` ra JSON, thay `public/data/core.json`.

## Ghi chú kỹ thuật

- Không dùng thư viện Supabase: `src/lib/api.js` gọi thẳng REST API (PostgREST + Auth), tự làm mới phiên đăng nhập.
- Tìm kiếm trên máy dùng đúng quy tắc chuẩn hoá chữ như hàm `f_norm` trong database.
- Lưu phiếu qua hàm `save_character` có kiểm tra `rev`, nên không ghi đè bản người khác vừa sửa.
- Khoá anon của Supabase để công khai được: mọi quyền đã khoá bằng Row Level Security trong `supabase/schema.sql`.
